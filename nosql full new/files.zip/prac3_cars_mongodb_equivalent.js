// PRACTICAL 3 (MongoDB version) - same steps, same order as the Cassandra file
// Run inside mongosh. Lines starting with // are expected output (safe to paste).
// Cassandra -> MongoDB: keyspace = database, table = collection, row = document,
// PRIMARY KEY = unique index, CONSISTENCY = read concern

// CREATE KEYSPACE car_db  /  USE car_db

use car_db

// Output: switched to db car_db


// DESCRIBE KEYSPACE car_db

db.getName()

// Output: car_db


// CREATE TABLE cars

db.createCollection("cars")

db.cars.createIndex({ car_id: 1 }, { unique: true })

// Output:
// { ok: 1 }
// car_id_1


// DESCRIBE TABLE cars

show collections

db.cars.getIndexes()

// Output:
// cars
// [ { v: 2, key: { _id: 1 }, name: '_id_' },
//   { v: 2, key: { car_id: 1 }, name: 'car_id_1', unique: true } ]


// INSERT INTO cars (5 cars)

db.cars.insertOne({ car_id: 101, manufacturer: "Toyota", type: "Sedan", max_performance: 203, max_torque: 243 })

db.cars.insertOne({ car_id: 102, manufacturer: "BMW", type: "Sedan", max_performance: 255, max_torque: 400 })

db.cars.insertOne({ car_id: 103, manufacturer: "Audi", type: "SUV", max_performance: 261, max_torque: 370 })

db.cars.insertOne({ car_id: 104, manufacturer: "Mercedes", type: "Sedan", max_performance: 255, max_torque: 400 })

db.cars.insertOne({ car_id: 105, manufacturer: "Ford", type: "SUV", max_performance: 250, max_torque: 380 })

// Output (each): { acknowledged: true, insertedId: ObjectId('...') }


// SELECT * FROM cars

db.cars.find({}, { _id: 0 })

// Output (insertion order):
// { car_id: 101, manufacturer: 'Toyota',   type: 'Sedan', max_performance: 203, max_torque: 243 }
// { car_id: 102, manufacturer: 'BMW',      type: 'Sedan', max_performance: 255, max_torque: 400 }
// { car_id: 103, manufacturer: 'Audi',     type: 'SUV',   max_performance: 261, max_torque: 370 }
// { car_id: 104, manufacturer: 'Mercedes', type: 'Sedan', max_performance: 255, max_torque: 400 }
// { car_id: 105, manufacturer: 'Ford',     type: 'SUV',   max_performance: 250, max_torque: 380 }


// Consistency levels (MongoDB uses read concern)

// CONSISTENCY;

db.getMongo().getReadConcern()

// Output: undefined   (default level is "local", the same idea as ONE)

// CONSISTENCY ONE;

db.getMongo().setReadConcern("local")

db.cars.find({}, { _id: 0 })

// Output: same 5 cars

// CONSISTENCY QUORUM;

db.getMongo().setReadConcern("majority")

db.cars.find({}, { _id: 0 })

// Output: same 5 cars (on one server majority is just that server)

// CONSISTENCY ALL;  (nearest match is "linearizable", needs a replica set, so it errors on a single server)

// db.getMongo().setReadConcern("linearizable")

// db.cars.find({ car_id: 101 }, { _id: 0 })

// CONSISTENCY ONE;

db.getMongo().setReadConcern("local")

// Output: (no output)


// Replication: run ONLY with a 3-member replica set (Cassandra's 3-node part)

// rs.initiate()

// rs.status()

// db.cars.find({}, { _id: 0 })
